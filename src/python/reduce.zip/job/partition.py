import hashlib


def partition(key, num_bins):
    key_hashed = int(hashlib.sha256(key.encode('utf-8')).hexdigest(), 16) % 10**8
    if key == "0.0.0.0":
        print("The hashed key is ", key_hashed)
    return key_hashed % num_bins
